﻿namespace Order.Service.Proxies
{
    public class AzureServiceBus
    {
        public string ConnectionString { get; set; }
    }
}

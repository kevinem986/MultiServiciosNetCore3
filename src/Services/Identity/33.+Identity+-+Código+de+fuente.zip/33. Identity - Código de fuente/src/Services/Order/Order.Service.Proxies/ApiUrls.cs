﻿namespace Order.Service.Proxies
{
    public class ApiUrls
    {
        public string CatalogUrl { get; set; }
    }
}

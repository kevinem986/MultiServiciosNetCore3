﻿namespace Catalog.Common
{
    public class Enums
    {
        public enum ProductInStockAction 
        {
            Add,
            Substract
        }
    }
}
